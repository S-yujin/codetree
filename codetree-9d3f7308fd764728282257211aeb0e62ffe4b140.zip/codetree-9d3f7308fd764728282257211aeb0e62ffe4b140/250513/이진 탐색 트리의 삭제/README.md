# [이진 탐색 트리의 삭제](https://www.codetree.ai/trails/complete/curated-cards/intro-bst-delete)

|유형|문제 경험치|난이도|
|---|---|---|
|[Trail 3 / 트리 / 이진 탐색 트리](https://www.codetree.ai/trail-info/novice-high/)|[[Concept]이진 탐색 트리의 삭제](https://www.codetree.ai/trails/complete/curated-cards/intro-bst-delete/)|어려움|

