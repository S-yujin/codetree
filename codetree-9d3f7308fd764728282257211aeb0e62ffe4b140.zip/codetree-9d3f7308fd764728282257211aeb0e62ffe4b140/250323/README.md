# 🌲 오늘의 Codetree 학습 현황 🌲

<br />

| <span style="color:red;display:block;text-align:center;"> **성취도**</span> | 결과 |
|---|---|
| 총 문제 수 | 2 |
| 획득 경험치 | 30 / 25 XP |
| 연속 학습 일 | 3 일 |

<br />

|커리큘럼|문제|난이도|상태|코드 링크|
|---|---|---|---|---|
|[Trail 2 / 정렬 / 객체](https://www.codetree.ai/trail-info/novice-mid/)|[[Concept]Next Level](https://www.codetree.ai/trails/complete/curated-cards/intro-next-level/)|쉬움|Solved|[링크](https://github.com/S-yujin/codetree/blob/main/250323/Next%20Level/next-level.cpp)|
|[Trail 2 / 정렬 / 객체](https://www.codetree.ai/trail-info/novice-mid/)|[[Concept]코드네임](https://www.codetree.ai/trails/complete/curated-cards/intro-code-name/)|쉬움|Solved|[링크](https://github.com/S-yujin/codetree/blob/main/250323/%EC%BD%94%EB%93%9C%EB%84%A4%EC%9E%84/code-name.cpp)|


<br />

> [!TIP]
> **경험치 획득** : 설명을 보지 않고 해결한 문제에 대해서만 한 번 경험치를 획득할 수 있습니다.  
> **학습 연속일** : 새로운 날에 새로운 경험치를 획득하면 연속일이 인정됩니다.

