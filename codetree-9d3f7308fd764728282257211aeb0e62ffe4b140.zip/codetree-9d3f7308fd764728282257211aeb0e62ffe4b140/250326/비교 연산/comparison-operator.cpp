#include <iostream>

using namespace std;

int main() {
    int a,b;
    cin>> a >>b;
    if (a>=b) {
        cout<<"1\n";
        }
    if (a<b) {
        cout<<"0\n";
    }
    
    if (a>b) {
        cout<<"1\n";
        }
     if (a<=b) {
        cout<<"0\n";
    }
    if (b>=a) {
        cout<<"1\n";
        }
     if (b<a) {
        cout<<"0\n";
    }
    if (b>a) {
        cout<<"1\n";
        }
     if (b<=a) {
        cout<<"0\n";
    }
    if (a==b) {
        cout<<"1\n";
        }
     if (a!=b) {
        cout<<"0\n";
    }
    if (a!=b) {
        cout<<"1\n";
        }
     if (a==b) {
        cout<<"0\n";
    }
}